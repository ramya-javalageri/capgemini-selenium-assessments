Action()
{

	lr_start_transaction("1_Launch");

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_cookie("Nop.customer=e7525458-08af-4b28-b207-c65cebd4b6d8; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("__utma=78382081.1454825896.1790836832.1790836832.1790836832.1; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("__utmb=78382081.26.10.1790836832; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("__utmz=78382081.1790836832.1.1.utmcsr=google|utmccn=(organic)|utmcmd=organic|utmctr=(not%20provided); DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("NopCommerce.RecentlyViewedProducts=RecentlyViewedProductIds=72; DOMAIN=demowebshop.tricentis.com");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

/*Correlation comment - Do not change!  Original value='build-your-cheap-own-computer' Name ='C_Product' Type ='Manual'*/
	web_reg_save_param_regexp(
		"ParamName=C_Product",
		"RegExp=a\\ href=\"/(.*?)\"\\ title",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_url("demowebshop.tricentis.com", 
		"URL=https://demowebshop.tricentis.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t139.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_cookie("__utmb=78382081.27.10.1790836832; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("__utmc=78382081; DOMAIN=demowebshop.tricentis.com");

	web_add_cookie("__utmt=1; DOMAIN=demowebshop.tricentis.com");

	web_websocket_send("ID=2", 
		"Buffer={\"messageType\":\"hello\",\"broadcasts\":{\"remote-settings/monitor_changes\":\"\\\"1790836606237\\\"\"},\"use_webpush\":true}", 
		"IsBinary=0", 
		LAST);

	/*Connection ID 2 received buffer WebSocketReceive0*/

	lr_end_transaction("1_Launch",LR_AUTO);

	lr_think_time(14);

	lr_output_message(
    "VUser=%s | Name=%s | Email=%s",
    lr_eval_string("{P_FN}"),
    lr_eval_string("{P_EMAIL}")
);
	
	lr_start_transaction("2_RegisterLink");

	web_url("Register", 
		"URL=https://demowebshop.tricentis.com/register", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/", 
		"Snapshot=t140.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("2_RegisterLink",LR_AUTO);

	lr_start_transaction("3_Register");

	web_add_cookie("__utmb=78382081.28.10.1790836832; DOMAIN=demowebshop.tricentis.com");

	web_submit_data("register", 
		"Action=https://demowebshop.tricentis.com/register", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/register", 
		"Snapshot=t141.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=__RequestVerificationToken", "Value=mqK-RSkWcqNRRYqcD4s-Kt8qkf2m780jmUgJnom3JFNix7vN0ctTKyUl07g7ehNEn8tlwBNCDNhstDxDkwov_izAnhoeFaHWmA2FDVtxM0w1", ENDITEM, 
		"Name=Gender", "Value=F", ENDITEM, 
		"Name=FirstName", "Value={P_FN}", ENDITEM, 
		"Name=LastName", "Value={P_LN}", ENDITEM, 
		"Name=Email", "Value={P_EMAIL}", ENDITEM, 
		"Name=Password", "Value={P_PWD}", ENDITEM, 
		"Name=ConfirmPassword", "Value={P_PWD}", ENDITEM, 
		"Name=register-button", "Value=Register", ENDITEM, 
		LAST);

	web_add_cookie("__utmb=78382081.29.10.1790836832; DOMAIN=demowebshop.tricentis.com");

	lr_end_transaction("3_Register",LR_AUTO);

	lr_think_time(13);

	lr_start_transaction("4_Continue");

	web_url("Tricentis Demo Web Shop", 
		"URL=https://demowebshop.tricentis.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/registerresult/1", 
		"Snapshot=t142.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_cookie("__utmb=78382081.30.10.1790836832; DOMAIN=demowebshop.tricentis.com");

	lr_end_transaction("4_Continue",LR_AUTO);

	lr_think_time(20);

	lr_start_transaction("5_Product");

	web_url("Build your own cheap computer",
		"URL=https://demowebshop.tricentis.com/{C_Product}",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://demowebshop.tricentis.com/",
		"Snapshot=t143.inf",
		"Mode=HTTP",
		LAST);

	lr_end_transaction("5_Product",LR_AUTO);

	lr_start_transaction("6_AddtoCart");

	web_add_cookie("__utmb=78382081.31.10.1790836832; DOMAIN=demowebshop.tricentis.com");

	lr_think_time(27);

	web_submit_data("1",
		"Action=https://demowebshop.tricentis.com/addproducttocart/details/72/1",
		"Method=POST",
		"RecContentType=application/json",
		"Referer=https://demowebshop.tricentis.com/{C_Product}",
		"Snapshot=t144.inf",
		"Mode=HTTP",
		ITEMDATA,
		"Name=product_attribute_72_5_18", "Value=53", ENDITEM,
		"Name=product_attribute_72_6_19", "Value=54", ENDITEM,
		"Name=product_attribute_72_3_20", "Value=57", ENDITEM,
		"Name=addtocart_72.EnteredQuantity", "Value=1", ENDITEM,
		LAST);

	lr_think_time(4);

	web_url("cart",
		"URL=https://demowebshop.tricentis.com/cart",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://demowebshop.tricentis.com/{C_Product}",
		"Snapshot=t145.inf",
		"Mode=HTTP",
		LAST);

	lr_end_transaction("6_AddtoCart",LR_AUTO);

	lr_start_transaction("7_CheckOut");

	web_add_cookie("__utmb=78382081.32.10.1790836832; DOMAIN=demowebshop.tricentis.com");

	web_submit_data("cart_2", 
		"Action=https://demowebshop.tricentis.com/cart", 
		"Method=POST", 
		"EncType=multipart/form-data", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/cart", 
		"Snapshot=t146.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=itemquantity7121206", "Value=1", ENDITEM, 
		"Name=discountcouponcode", "Value=", ENDITEM, 
		"Name=giftcardcouponcode", "Value=", ENDITEM, 
		"Name=CountryId", "Value=0", ENDITEM, 
		"Name=StateProvinceId", "Value=0", ENDITEM, 
		"Name=ZipPostalCode", "Value=", ENDITEM, 
		"Name=termsofservice", "Value=on", ENDITEM, 
		"Name=checkout", "Value=checkout", ENDITEM, 
		LAST);

	lr_end_transaction("7_CheckOut",LR_AUTO);

	lr_start_transaction("8_BillingAdress");

	web_add_cookie("__utmb=78382081.33.10.1790836832; DOMAIN=demowebshop.tricentis.com");

	lr_think_time(24);

	web_url("getstatesbycountryid", 
		"URL=https://demowebshop.tricentis.com/country/getstatesbycountryid?countryId=41&addEmptyStateIfRequired=true&_=1790839386084", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t147.inf", 
		"Mode=HTTP", 
		LAST);

	lr_think_time(28);

	web_submit_data("OpcSaveBilling", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSaveBilling/", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t148.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=BillingNewAddress.Id", "Value=0", ENDITEM, 
		"Name=BillingNewAddress.FirstName", "Value={P_FN}", ENDITEM, 
		"Name=BillingNewAddress.LastName", "Value={P_LN}", ENDITEM, 
		"Name=BillingNewAddress.Email", "Value={P_EMAIL}", ENDITEM, 
		"Name=BillingNewAddress.Company", "Value=", ENDITEM, 
		"Name=BillingNewAddress.CountryId", "Value=41", ENDITEM, 
		"Name=BillingNewAddress.StateProvinceId", "Value=0", ENDITEM, 
		"Name=BillingNewAddress.City", "Value=Narayaapet", ENDITEM, 
		"Name=BillingNewAddress.Address1", "Value=2-14/", ENDITEM, 
		"Name=BillingNewAddress.Address2", "Value=Maganoor", ENDITEM, 
		"Name=BillingNewAddress.ZipPostalCode", "Value={P_Zip}", ENDITEM, 
		"Name=BillingNewAddress.PhoneNumber", "Value=7896541230", ENDITEM, 
		"Name=BillingNewAddress.FaxNumber", "Value=", ENDITEM, 
		LAST);

	lr_end_transaction("8_BillingAdress",LR_AUTO);

	web_submit_data("OpcSaveShipping", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSaveShipping/", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t149.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=shipping_address_id", "Value=5159467", ENDITEM, 
		"Name=ShippingNewAddress.Id", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.FirstName", "Value={P_FN}", ENDITEM, 
		"Name=ShippingNewAddress.LastName", "Value=J", ENDITEM, 
		"Name=ShippingNewAddress.Email", "Value={P_EMAIL}", ENDITEM, 
		"Name=ShippingNewAddress.Company", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.CountryId", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.StateProvinceId", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.City", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.Address1", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.Address2", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.ZipPostalCode", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.PhoneNumber", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.FaxNumber", "Value=", ENDITEM, 
		"Name=PickUpInStore", "Value=false", ENDITEM, 
		LAST);

	lr_think_time(14);

	lr_start_transaction("9_Shipping");

	web_submit_data("OpcSaveShipping_2", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSaveShipping/", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t150.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=shipping_address_id", "Value=5159467", ENDITEM, 
		"Name=ShippingNewAddress.Id", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.FirstName", "Value={P_FN}", ENDITEM, 
		"Name=ShippingNewAddress.LastName", "Value=J", ENDITEM, 
		"Name=ShippingNewAddress.Email", "Value={P_EMAIL}", ENDITEM, 
		"Name=ShippingNewAddress.Company", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.CountryId", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.StateProvinceId", "Value=0", ENDITEM, 
		"Name=ShippingNewAddress.City", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.Address1", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.Address2", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.ZipPostalCode", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.PhoneNumber", "Value=", ENDITEM, 
		"Name=ShippingNewAddress.FaxNumber", "Value=", ENDITEM, 
		"Name=PickUpInStore", "Value=false", ENDITEM, 
		LAST);

	lr_end_transaction("9_Shipping",LR_AUTO);

	lr_think_time(20);

	lr_start_transaction("10_ShiipingMethod");

	web_submit_data("OpcSaveShippingMethod", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSaveShippingMethod/", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t151.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=shippingoption", "Value=Next Day Air___Shipping.FixedRate", ENDITEM, 
		LAST);

	lr_end_transaction("10_ShiipingMethod",LR_AUTO);

	lr_think_time(15);

	lr_start_transaction("11_PaymentMethod");

	web_submit_data("OpcSavePaymentMethod", 
		"Action=https://demowebshop.tricentis.com/checkout/OpcSavePaymentMethod/", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t152.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=paymentmethod", "Value=Payments.CheckMoneyOrder", ENDITEM, 
		LAST);

	lr_end_transaction("11_PaymentMethod",LR_AUTO);

	lr_think_time(16);

	lr_start_transaction("12_PaymentInfo");

	web_custom_request("OpcSavePaymentInfo", 
		"URL=https://demowebshop.tricentis.com/checkout/OpcSavePaymentInfo/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t153.inf", 
		"Mode=HTTP", 
		"EncType=", 
		LAST);

	lr_end_transaction("12_PaymentInfo",LR_AUTO);

	lr_think_time(13);

	lr_start_transaction("13_Confirm");

	web_custom_request("OpcConfirmOrder", 
		"URL=https://demowebshop.tricentis.com/checkout/OpcConfirmOrder/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t154.inf", 
		"Mode=HTTP", 
		"EncType=", 
		LAST);

	web_url("completed", 
		"URL=https://demowebshop.tricentis.com/checkout/completed/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demowebshop.tricentis.com/onepagecheckout", 
		"Snapshot=t155.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("13_Confirm",LR_AUTO);

	return 0;
}