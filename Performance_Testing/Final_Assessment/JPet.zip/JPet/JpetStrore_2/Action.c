Action()
{

	lr_think_time(2);
	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

/*Correlation comment - Do not change!  Original value='FISH' Name ='C_Category' Type ='Manual'*/
	web_reg_save_param_regexp(
		"ParamName=C_Category",
		"RegExp=categories/(.*?)\">",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_url("jpetstore.aspectran.com", 
		"URL=https://jpetstore.aspectran.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTTP", 
		LAST);

	web_websocket_send("ID=0", 
		"Buffer={\"messageType\":\"hello\",\"broadcasts\":{\"remote-settings/monitor_changes\":\"\\\"1790782790614\\\"\"},\"use_webpush\":true}", 
		"IsBinary=0", 
		LAST);

	/*Connection ID 0 received buffer WebSocketReceive0*/

	lr_start_transaction("1_Launch");

	lr_end_transaction("1_Launch",LR_AUTO);

	lr_start_transaction("2_Category");

/*Correlation comment - Do not change!  Original value='FI-SW-02' Name ='C_Product' Type ='Manual'*/
	web_reg_save_param_regexp(
		"ParamName=C_Product",
		"RegExp=products/(.*?)\">",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_url("Fish",
		"URL=https://jpetstore.aspectran.com/categories/{C_Category}",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/",
		"Snapshot=t2.inf",
		"Mode=HTTP",
		LAST);

	lr_end_transaction("2_Category",LR_AUTO);

	lr_think_time(12);

	lr_start_transaction("3_Product");

/*Correlation comment - Do not change!  Original value='EST-3' Name ='C_ItemId' Type ='Manual'*/
	web_reg_save_param_regexp(
		"ParamName=C_ItemId",
		"RegExp=items/(.*?)\">",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_url("FI-SW-02",
		"URL=https://jpetstore.aspectran.com/products/{C_Product}",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/categories/{C_Category}",
		"Snapshot=t3.inf",
		"Mode=HTTP",
		LAST);

	lr_end_transaction("3_Product",LR_AUTO);

	lr_think_time(12);

	lr_start_transaction("4_ItemId");

	web_url("EST-3",
		"URL=https://jpetstore.aspectran.com/products/{C_Product}/items/{C_ItemId}",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/products/{C_Product}",
		"Snapshot=t4.inf",
		"Mode=HTTP",
		LAST);

	lr_end_transaction("4_ItemId",LR_AUTO);

	lr_start_transaction("5_AddToCart");

	web_url("Add to Cart",
		"URL=https://jpetstore.aspectran.com/cart/addItemToCart?itemId={C_ItemId}",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/products/{C_Product}/items/{C_ItemId}",
		"Snapshot=t5.inf",
		"Mode=HTTP",
		LAST);

	lr_end_transaction("5_AddToCart",LR_AUTO);

	lr_start_transaction("6_CheckOut");

	web_url("Proceed to Checkout", 
		"URL=https://jpetstore.aspectran.com/order/newOrderForm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/cart/viewCart", 
		"Snapshot=t6.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("6_CheckOut",LR_AUTO);

	lr_start_transaction("7_Login");

	web_submit_data("signon", 
		"Action=https://jpetstore.aspectran.com/account/signon", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/account/signonForm?referer=/order/newOrderForm", 
		"Snapshot=t7.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=referer", "Value=/order/newOrderForm", ENDITEM, 
		"Name=username", "Value={P_Username}", ENDITEM, 
		"Name=password", "Value={P_Password}", ENDITEM, 
		LAST);

	lr_end_transaction("7_Login",LR_AUTO);

	lr_think_time(12);

	lr_start_transaction("8_Continue");

	web_submit_data("newOrder", 
		"Action=https://jpetstore.aspectran.com/order/newOrder", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/order/newOrderForm", 
		"Snapshot=t8.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=paymentForm", "Value=true", ENDITEM, 
		"Name=billingForm", "Value=true", ENDITEM, 
		"Name=cardType", "Value=Visa", ENDITEM, 
		"Name=creditCard", "Value={P_CreditNum}", ENDITEM, 
		"Name=expiryDate", "Value=12/2019", ENDITEM, 
		"Name=billToFirstName", "Value=Test", ENDITEM, 
		"Name=billToLastName", "Value=User", ENDITEM, 
		"Name=billAddress1", "Value=123 Test St", ENDITEM, 
		"Name=billAddress2", "Value=123 Test St", ENDITEM, 
		"Name=billCity", "Value=Testville", ENDITEM, 
		"Name=billState", "Value=CA", ENDITEM, 
		"Name=billZip", "Value={P_ZipCode}", ENDITEM, 
		"Name=billCountry", "Value=US", ENDITEM, 
		LAST);

	lr_end_transaction("8_Continue",LR_AUTO);

	lr_start_transaction("9_Confirm");

	web_submit_data("submitOrder", 
		"Action=https://jpetstore.aspectran.com/order/submitOrder", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/order/newOrder", 
		"Snapshot=t9.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=confirmed", "Value=true", ENDITEM, 
		LAST);

	lr_end_transaction("9_Confirm",LR_AUTO);

	return 0;
}